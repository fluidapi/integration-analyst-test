package desafio.converter2;

import java.io.IOException;

public   class Principal {
    public static void main(String[] args) throws IOException {
        Arquivo arquivo = new Arquivo();
        arquivo.ler();


    }}